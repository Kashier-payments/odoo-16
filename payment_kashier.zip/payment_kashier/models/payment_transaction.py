# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import pprint
from werkzeug import urls

from odoo import _, api, models
from odoo.exceptions import ValidationError
from odoo.tools.float_utils import float_compare

from odoo.addons.payment_kashier.controllers.main import KashierController

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        """ Override of payment to return Kashier-specific rendering values.

        Note: self.ensure_one() from `_get_processing_values`

        :param dict processing_values: The generic and specific processing values of the transaction
        :return: The dict of provider-specific processing values
        :rtype: dict
        """
       
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'kashier':
            return res
        
        base_url = self.provider_id.get_base_url()
        if self.fees:
            # Similarly to what is done in `payment::payment.transaction.create`, we need to round
            # the sum of the amount and of the fees to avoid inconsistent string representations.
            # E.g., str(1111.11 + 7.09) == '1118.1999999999998'
            total_fee = self.currency_id.round(self.amount + self.fees)
        else:
            total_fee = self.amount
        rendering_values = {
            '_input_charset': 'utf-8',
            'notify_url': urls.url_join(base_url, KashierController._webhook_url),
            'out_trade_no': self.reference,
            'partner': self.provider_id.kashier_merchant_id,
            'kashier_key': self.provider_id.kashier_key,
            'return_url': urls.url_join(base_url, KashierController._return_url),
            'subject': self.reference,
           
            "allowedMethods":"card,wallet,bank_installments",
            'total_fee': f'{total_fee:.2f}',
        }
        if self.provider_id.kashier_payment_method == 'standard_checkout':
            # https://global.kashier.com/docs/ac/global/create_forex_trade
            rendering_values.update({
                'service': 'create_forex_trade',
                'product_code': 'NEW_OVERSEAS_SELLER',
                'currency': self.currency_id.name,
            })
        else:
            rendering_values.update({
                'service': 'create_direct_pay_by_user',
                'payment_type': 1,
            })

        sign = self.provider_id._kashier_compute_signature(rendering_values)
        rendering_values.update({
             'mode': self.provider_id._kashier_get_mode(),
            'sign': sign,
            'api_url': self.provider_id._kashier_get_api_url(),
        })
        return rendering_values

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """ Override of payment to find the transaction based on kashier data.

        :param str provider_code: The code of the provider that handled the transaction
        :param dict notification_data: The notification data sent by the provider
        :return: The transaction if found
        :rtype: recordset of `payment.transaction`
        :raise: ValidationError if inconsistent data were received
        :raise: ValidationError if the data match no transaction
        """
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'kashier' or len(tx) == 1:
            return tx

        
        reference = notification_data.get('merchantOrderId')
        if not reference:
            raise ValidationError("kashier: " + _("Received data with missing reference."))
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'kashier')])
        _logger.info("api tx_sudo is :\n%s", reference)

        if not tx:
            raise ValidationError(
                "kashier: " + _("No transaction found matching reference %s.", reference)
            )

        return tx


        

    def _process_notification_data(self, notification_data):
        """ Override of payment to process the transaction based on Kashier data.

        Note: self.ensure_one()

        :param dict notification_data: The notification data sent by the provider
        :return: None
        :raise: ValidationError if inconsistent data were received
        """
        super()._process_notification_data(notification_data)
        if self.provider_code != 'kashier':
            return

        self.provider_reference = notification_data.get('merchantOrderId')
        status = notification_data.get('paymentStatus')
        _logger.info('Kashier: entering notification_data with notification_data data %s', pprint.pformat(notification_data))         
        payment_status = notification_data.get('paymentStatus')

        if payment_status == 'SUCCESS':
            self._set_done()
        else:
            self._set_canceled()
            self._set_error("Kashier: " + _("received invalid transaction status: %s", status))
